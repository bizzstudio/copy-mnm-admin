import{j as t,d as a}from"./index-tUCO0ehZ.js";const n=({label:s,oneLine:o=!1,className:e})=>t.jsx(a.Label,{className:`${e} col-span-6 font-semibold text-sm`,children:s});export{n as L};
