import{j as t,f as a}from"./index-CVR3KhDg.js";const n=({label:s,oneLine:o=!1,className:e})=>t.jsx(a.Label,{className:`${e} col-span-6 font-semibold text-sm`,children:s});export{n as L};
